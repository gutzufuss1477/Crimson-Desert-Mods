Healthbar_always_on_2.00.00

Persistent enemy HP bars with the Caites-style multitarget presentation for Crimson Desert 2.00.00.

Game version: Crimson Desert 2.00.00
Author: Blablup / UI persistence by Caites

Important: Use only one Healthbar variant at the same time.
