Steelheart_Horseshoes_20_Stamina_Regen_2.00.00

Sets the Steelheart Horseshoes stamina-regeneration equip-buff level from 4 to 20. Only item 1000594 is targeted.

Game version: Crimson Desert 2.00.00
Author: Blablup
