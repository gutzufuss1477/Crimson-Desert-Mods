All_Mounts_LvL_5_Speed_2.00.00

Sets only the movement-speed rating in all compatible mount stat blocks to level 5 for Crimson Desert 2.00.00.

Game version: Crimson Desert 2.00.00
Author: Blablup

Important: Use only one All_Mounts_LvL_5 variant at the same time.
