Healthbar_always_on_classic_vanilla_single_target_2.00.00

Persistent classic vanilla-style single-target enemy HP bar for Crimson Desert 2.00.00.

Game version: Crimson Desert 2.00.00
Author: Blablup / UI persistence by Caites

Important: Use only one Healthbar variant at the same time.
