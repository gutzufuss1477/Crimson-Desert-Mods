All_Mounts_LvL_5_All_Stats_2.00.00

Sets movement speed, acceleration, turning and jump in all compatible mount stat blocks to level 5 for Crimson Desert 2.00.00.

Game version: Crimson Desert 2.00.00
Author: Blablup

Important: Use only one All_Mounts_LvL_5 variant at the same time.
