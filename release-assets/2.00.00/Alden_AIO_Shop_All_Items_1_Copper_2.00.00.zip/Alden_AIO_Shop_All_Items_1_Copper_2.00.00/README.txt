Alden_AIO_Shop_All_Items_1_Copper_2.00.00

Ports the original 379-item Alden shop catalog to Crimson Desert 2.00.00 with the original item order and stock quantities. All listed purchase prices are set to 1 copper.

Game version: Crimson Desert 2.00.00
Author: Blablup
