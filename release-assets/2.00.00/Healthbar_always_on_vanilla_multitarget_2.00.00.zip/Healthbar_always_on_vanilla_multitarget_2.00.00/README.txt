Healthbar_always_on_vanilla_multitarget_2.00.00

Persistent vanilla-style multitarget enemy HP bars for Crimson Desert 2.00.00.

Game version: Crimson Desert 2.00.00
Author: Blablup / UI persistence by Caites

Important: Use only one Healthbar variant at the same time.
